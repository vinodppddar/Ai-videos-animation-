from pathlib import Path
from uuid import uuid4
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session
from app.config import settings
from app.database import get_db
from app.models import Asset, Project, User
from app.utils.deps import get_current_user

router = APIRouter(prefix="/api/assets", tags=["Assets"])
ALLOWED = {"image/jpeg", "image/png", "image/webp"}

@router.post("/upload")
async def upload_image(project_id: int, file: UploadFile = File(...), db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    project = db.query(Project).filter(Project.id == project_id, Project.user_id == user.id).first()
    if not project: raise HTTPException(404, "Project not found")
    if file.content_type not in ALLOWED: raise HTTPException(400, "Only JPG, PNG and WEBP images are supported")
    data = await file.read()
    if len(data) > settings.max_upload_mb * 1024 * 1024: raise HTTPException(413, "Image is too large")
    ext = Path(file.filename or "image.png").suffix.lower() or ".png"
    path = Path(settings.upload_dir); path.mkdir(parents=True, exist_ok=True)
    dest = path / f"{uuid4().hex}{ext}"; dest.write_bytes(data)
    asset = Asset(project_id=project.id, asset_type="image", file_path=str(dest), file_size=len(data))
    db.add(asset); db.commit(); db.refresh(asset)
    return {"id": asset.id, "project_id": project.id, "filename": file.filename, "size": len(data)}
