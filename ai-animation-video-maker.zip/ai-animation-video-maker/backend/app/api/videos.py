from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Project, Prompt, Video, VideoJob, Asset, User
from app.schemas import GenerateRequest, JobOut
from app.services.prompt_service import structure_prompt
from app.utils.deps import get_current_user, get_current_user_optional
from app.utils.security import decode_token
from app.workers.video_worker import generate_video

router = APIRouter(prefix="/api/videos", tags=["Videos"])

@router.post("/generate", response_model=JobOut)
def generate(data: GenerateRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    project = db.query(Project).filter(Project.id == data.project_id, Project.user_id == user.id).first()
    if not project: raise HTTPException(404, "Project not found")
    asset = db.query(Asset).filter(Asset.project_id == project.id, Asset.asset_type == "image").order_by(Asset.id.desc()).first()
    if not asset: raise HTTPException(400, "Upload an image first")
    if not data.prompt.strip(): raise HTTPException(400, "Prompt is required")
    prompt = Prompt(project_id=project.id, prompt_text=data.prompt.strip(), processed_prompt=structure_prompt(data.prompt, data.dialogue, data.language), dialogue=data.dialogue, language=data.language)
    db.add(prompt)
    job = VideoJob(project_id=project.id, status="queued", progress=0, model="demo-ffmpeg" if __import__('app.config', fromlist=['settings']).settings.demo_mode else (__import__('app.config', fromlist=['settings']).settings.ai_provider_model or "external"))
    project.status = "processing"; db.add(job); db.commit(); db.refresh(job)
    generate_video.delay(job.id)
    return job_to_out(db, job)

def job_to_out(db, job):
    video = db.query(Video).filter(Video.project_id == job.project_id).order_by(Video.id.desc()).first() if job.status == "completed" else None
    return JobOut(id=job.id, status=job.status, progress=job.progress, model=job.model, error_message=job.error_message, video_id=video.id if video else None)

@router.get("/jobs/{job_id}", response_model=JobOut)
def job_status(job_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    job = db.query(VideoJob).join(Project).filter(VideoJob.id == job_id, Project.user_id == user.id).first()
    if not job: raise HTTPException(404, "Job not found")
    return job_to_out(db, job)

@router.get("/{video_id}/download")
def download(video_id: int, token: str | None = Query(default=None), db: Session = Depends(get_db), user: User | None = Depends(get_current_user_optional)):
    # Browser download links cannot attach an Authorization header, so a short-lived token query parameter is also accepted.
    if user is None and token:
        try:
            user = db.get(User, decode_token(token))
        except Exception:
            user = None
    if user is None:
        raise HTTPException(401, "Authentication required")
    video = db.query(Video).join(Project).filter(Video.id == video_id, Project.user_id == user.id).first()
    if not video: raise HTTPException(404, "Video not found")
    return FileResponse(video.video_path, media_type="video/mp4", filename=f"animation-{video.id}.mp4")
