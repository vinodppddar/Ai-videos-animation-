from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    secret_key: str = "change-this-in-production"
    database_url: str = "sqlite:///./animation.db"
    redis_url: str = "redis://localhost:6379/0"
    cors_origins: str = "http://localhost:5173"
    upload_dir: str = "./storage/uploads"
    generated_dir: str = "./storage/generated"
    max_upload_mb: int = 10
    demo_mode: bool = True
    ai_provider_url: str | None = None
    ai_provider_token: str | None = None
    ai_provider_model: str | None = None
    public_api_url: str = "http://localhost:8000"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def cors_list(self):
        return [x.strip() for x in self.cors_origins.split(",") if x.strip()]

@lru_cache
def get_settings():
    return Settings()

settings = get_settings()
