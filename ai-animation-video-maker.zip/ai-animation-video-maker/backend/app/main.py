from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from app.config import settings
from app.database import Base, engine
from app.models import *
from app.api import auth, projects, assets, videos

Path(settings.upload_dir).mkdir(parents=True, exist_ok=True)
Path(settings.generated_dir).mkdir(parents=True, exist_ok=True)
Base.metadata.create_all(bind=engine)

app = FastAPI(title="AI Animation Video Maker API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_list, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.mount("/media", StaticFiles(directory=settings.generated_dir), name="media")
app.include_router(auth.router); app.include_router(projects.router); app.include_router(assets.router); app.include_router(videos.router)

@app.get("/")
def root(): return {"name": "AI Animation Video Maker API", "version": "1.0.0", "docs": "/docs"}

@app.get("/health")
def health(): return {"status": "ok"}
