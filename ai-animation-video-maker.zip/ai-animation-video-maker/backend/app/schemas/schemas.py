from datetime import datetime
from pydantic import BaseModel, EmailStr, ConfigDict

class RegisterRequest(BaseModel):
    name: str
    email: EmailStr
    password: str

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict

class ProjectCreate(BaseModel):
    project_name: str

class ProjectOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    project_name: str
    status: str
    created_at: datetime

class GenerateRequest(BaseModel):
    project_id: int
    prompt: str
    dialogue: str | None = None
    language: str = "English"
    duration: int = 5

class JobOut(BaseModel):
    id: int
    status: str
    progress: int
    model: str
    error_message: str | None = None
    video_id: int | None = None
