import base64
from pathlib import Path
import httpx
from app.config import settings

class AnimationProviderError(Exception):
    pass

class AnimationProvider:
    async def generate(self, image_path: str, prompt: str, duration: int, dialogue: str | None):
        if settings.demo_mode:
            from app.services.demo_renderer import render_demo_video
            return await render_demo_video(image_path, duration)

        if not settings.ai_provider_url:
            raise AnimationProviderError("AI_PROVIDER_URL is not configured and DEMO_MODE is false")

        image_bytes = Path(image_path).read_bytes()
        suffix = Path(image_path).suffix.lower().replace('.', '') or 'png'
        mime = {'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png', 'webp': 'image/webp'}.get(suffix, 'image/png')
        data_uri = f"data:{mime};base64," + base64.b64encode(image_bytes).decode()
        payload = {
            "model": settings.ai_provider_model,
            "image_data_uri": data_uri,
            "prompt": prompt,
            "duration": duration,
            "dialogue": dialogue,
        }
        headers = {"Authorization": f"Bearer {settings.ai_provider_token}"} if settings.ai_provider_token else {}
        async with httpx.AsyncClient(timeout=300) as client:
            response = await client.post(settings.ai_provider_url, json=payload, headers=headers)
            response.raise_for_status()
            result = response.json()

        if result.get("video_url"):
            return {"video_url": result["video_url"]}
        if result.get("video_data_base64"):
            return {"video_bytes": base64.b64decode(result["video_data_base64"])}
        raise AnimationProviderError("Provider response must contain video_url or video_data_base64")
