import asyncio
import subprocess
from pathlib import Path
from uuid import uuid4
from app.config import settings

async def render_demo_video(image_path: str, duration: int):
    out_dir = Path(settings.generated_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    output = out_dir / f"demo_{uuid4().hex}.mp4"
    duration = max(3, min(duration, 15))
    fps = 24
    frames = duration * fps
    # Subtle zoom + horizontal drift. This is a real MP4 generation fallback.
    vf = (
        f"scale=1280:720:force_original_aspect_ratio=decrease,"
        f"pad=1280:720:(ow-iw)/2:(oh-ih)/2,"
        f"zoompan=z='min(zoom+0.0008,1.12)':x='iw/2-(iw/zoom/2)+sin(on/18)*10':"
        f"y='ih/2-(ih/zoom/2)':d=1:s=1280x720:fps={fps},"
        f"format=yuv420p"
    )
    cmd = [
        "ffmpeg", "-y", "-loop", "1", "-i", image_path,
        "-vf", vf, "-frames:v", str(frames), "-an", "-c:v", "libx264",
        "-preset", "veryfast", "-movflags", "+faststart", str(output)
    ]
    await asyncio.to_thread(subprocess.run, cmd, check=True, capture_output=True)
    return {"video_path": str(output)}
