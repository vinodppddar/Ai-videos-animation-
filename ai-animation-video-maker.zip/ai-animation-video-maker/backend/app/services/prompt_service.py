import json

def structure_prompt(prompt: str, dialogue: str | None, language: str):
    text = prompt.strip()
    intent = {
        "raw_prompt": text,
        "actions": [text],
        "expression": "natural",
        "camera": "subtle cinematic movement",
        "speech": dialogue or None,
        "language": language,
    }
    return json.dumps(intent)
