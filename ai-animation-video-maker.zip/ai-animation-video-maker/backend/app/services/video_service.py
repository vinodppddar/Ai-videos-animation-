from pathlib import Path
import httpx
from sqlalchemy.orm import Session
from app.config import settings
from app.models import Video, VideoJob, Project
from app.services.animation_provider import AnimationProvider

async def run_generation(db: Session, job: VideoJob, image_path: str, prompt: str, duration: int, dialogue: str | None):
    from datetime import datetime, timezone
    job.status = "processing"; job.progress = 10; job.started_at = datetime.now(timezone.utc); db.commit()
    provider = AnimationProvider()
    try:
        result = await provider.generate(image_path, prompt, duration, dialogue)
        job.progress = 85; db.commit()
        out_dir = Path(settings.generated_dir); out_dir.mkdir(parents=True, exist_ok=True)
        output = out_dir / f"video_{job.id}.mp4"
        if result.get("video_path"):
            Path(result["video_path"]).replace(output)
        elif result.get("video_bytes"):
            output.write_bytes(result["video_bytes"])
        elif result.get("video_url"):
            async with httpx.AsyncClient(timeout=300) as client:
                r = await client.get(result["video_url"]); r.raise_for_status(); output.write_bytes(r.content)
        else:
            raise RuntimeError("No video output returned")
        video = Video(project_id=job.project_id, video_path=str(output), duration=duration, resolution="720p")
        db.add(video)
        job.status = "completed"; job.progress = 100; job.completed_at = datetime.now(timezone.utc)
        project = db.get(Project, job.project_id)
        if project: project.status = "completed"
        db.commit(); db.refresh(video)
        return video
    except Exception as exc:
        job.status = "failed"; job.progress = 100; job.error_message = str(exc)[:1000]; db.commit()
        raise
