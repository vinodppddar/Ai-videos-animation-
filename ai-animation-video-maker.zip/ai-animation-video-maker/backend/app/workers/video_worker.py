import asyncio
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models import Asset, Prompt, VideoJob
from app.services.video_service import run_generation
from app.workers.celery_app import celery

@celery.task(name="generate_video")
def generate_video(job_id: int):
    db: Session = SessionLocal()
    try:
        job = db.get(VideoJob, job_id)
        if not job: return
        prompt = db.query(Prompt).filter(Prompt.project_id == job.project_id).order_by(Prompt.id.desc()).first()
        asset = db.query(Asset).filter(Asset.project_id == job.project_id, Asset.asset_type == "image").order_by(Asset.id.desc()).first()
        if not prompt or not asset:
            raise RuntimeError("Project is missing image or prompt")
        asyncio.run(run_generation(db, job, asset.file_path, prompt.prompt_text, 5, prompt.dialogue))
    finally:
        db.close()
