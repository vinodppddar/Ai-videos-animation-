export const API = import.meta.env.VITE_API_URL || 'http://localhost:8000';

async function request(path:string, options:RequestInit={}){
  const token=localStorage.getItem('token');
  const headers=new Headers(options.headers);
  if(token) headers.set('Authorization',`Bearer ${token}`);
  const res=await fetch(`${API}${path}`,{...options,headers});
  if(!res.ok){const data=await res.json().catch(()=>({}));throw new Error(data.detail||'Request failed')}
  return res.json();
}
export const api={
  register:(body:any)=>request('/api/auth/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),
  login:(body:any)=>request('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),
  projects:()=>request('/api/projects'),
  createProject:(name:string)=>request('/api/projects',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({project_name:name})}),
  upload:async(projectId:number,file:File)=>{const fd=new FormData();fd.append('file',file);return request(`/api/assets/upload?project_id=${projectId}`,{method:'POST',body:fd})},
  generate:(body:any)=>request('/api/videos/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),
  job:(id:number)=>request(`/api/videos/jobs/${id}`),
  download:(id:number)=>`${API}/api/videos/${id}/download?token=${localStorage.getItem('token')}`
}
